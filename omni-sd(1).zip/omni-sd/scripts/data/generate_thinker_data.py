#!/usr/bin/env python
r"""Generate Qwen3-Omni Thinker responses for drafter model training.

Usage:
  # One persistent Thinker replica per GPU. Completed Parquet shards are
  # skipped on restart, so the same command resumes safely. ``run`` is the
  # default and can be omitted.
  CUDA_VISIBLE_DEVICES=0,1 torchrun --standalone --nproc-per-node=2 \
    scripts/data/generate_thinker_data.py

  # Optional recovery command: rebuild manifest.json without generation.
  python scripts/data/generate_thinker_data.py verify

All paths, sampling parameters, batch sizes, and shard sizes have defaults in
``configs/generate_thinker_data.yaml``. Only the Thinker component is loaded.
Each output row contains OpenAI-style messages with the generated assistant
response plus the exact prompt/response token IDs.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import json
import math
import os
from pathlib import Path
import socket
import sys
import time
from typing import Any, Iterable

import pyarrow as pa
import pyarrow.parquet as pq
import yaml


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
if str(REPOSITORY_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT / "src"))

from omni_sd.data_io import ParquetBatchWriter, atomic_write_json
from omni_sd.thinker_data import canonical_json, stable_hex, stable_int


DEFAULT_CONFIG = "configs/generate_thinker_data.yaml"
TRAJECTORY_SCHEMA = pa.schema(
    [
        ("condition_id", pa.string()),
        ("source", pa.string()),
        ("source_subset", pa.string()),
        ("modality", pa.string()),
        ("language", pa.string()),
        ("task", pa.string()),
        ("messages_json", pa.large_string()),
        ("tools_json", pa.large_string()),
        ("media_json", pa.large_string()),
        ("prompt_token_ids", pa.large_list(pa.int32())),
        ("response_token_ids", pa.large_list(pa.int32())),
        ("response_text", pa.large_string()),
        ("prompt_tokens", pa.int32()),
        ("response_tokens", pa.int32()),
        ("finish_reason", pa.string()),
        ("sampling_seed", pa.int64()),
    ]
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        "command", nargs="?", choices=("run", "verify"), default="run"
    )
    parser.add_argument("--config", default=DEFAULT_CONFIG)
    parser.add_argument("--max-shards", type=int, default=None)
    return parser.parse_args()


def read_config(path: str | Path) -> dict[str, Any]:
    with Path(path).open(encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def paths(config: dict[str, Any]) -> tuple[Path, Path, Path]:
    input_path = Path(config["input"]["conditions"])
    marker = Path(config["input"]["success_marker"])
    output = Path(config["output"]["root"])
    return input_path, marker, output


def generation_fingerprint(config: dict[str, Any]) -> str:
    """Prevent a resumed directory from mixing models or sampling policies."""
    return stable_hex(
        config["model"],
        config["generation"],
        config["batch_size"],
        int(config["output"]["conditions_per_shard"]),
    )


def require_verified_input(config: dict[str, Any]) -> tuple[Path, int]:
    input_path, marker_path, _ = paths(config)
    if not input_path.is_file() or not marker_path.is_file():
        raise FileNotFoundError("accepted Thinker conditions are not ready")
    marker = json.loads(marker_path.read_text(encoding="utf-8"))
    expected = int(config["input"]["expected_conditions"])
    if marker.get("status") != "PASS" or int(marker.get("conditions", -1)) != expected:
        raise ValueError("accepted Thinker dataset has not passed exact-count verification")
    rows = pq.ParquetFile(input_path).metadata.num_rows
    if rows != expected:
        raise ValueError(f"accepted condition count {rows} != {expected}")
    return input_path, rows


def media_content(item: dict[str, Any], generation: dict[str, Any]) -> dict[str, Any]:
    media_type = str(item["type"]).lower()
    path = Path(str(item.get("path", "")))
    if not path.is_file():
        raise FileNotFoundError(path)
    content: dict[str, Any] = {"type": media_type, media_type: str(path)}
    if media_type == "image":
        content["max_pixels"] = int(generation["image_max_pixels"])
    elif media_type == "video":
        content.update(
            fps=float(generation["video_fps"]),
            min_frames=int(generation["video_min_frames"]),
            max_frames=int(generation["video_max_frames"]),
            # qwen_omni_utils accepts this per-video argument directly. The
            # factor is the official 14-pixel patch times spatial merge 2.
            total_pixels=int(generation["max_model_tokens"] * 28**2 * 0.9),
        )
    elif media_type != "audio":
        raise ValueError(f"unsupported media type: {media_type}")
    return content


def model_conversation(
    row: dict[str, Any], generation: dict[str, Any]
) -> list[dict[str, Any]]:
    messages = json.loads(str(row["messages_json"]))
    media = json.loads(str(row["media_json"]))
    system_prompt = generation.get("system_prompt")
    if system_prompt:
        messages.insert(0, {"role": "system", "content": str(system_prompt)})
    if media:
        user_index = next(
            index for index in range(len(messages) - 1, -1, -1)
            if messages[index]["role"] == "user"
        )
        text = str(messages[user_index]["content"])
        messages[user_index] = {
            "role": "user",
            # Qwen recommends media before the textual task instruction.
            "content": [
                *(media_content(item, generation) for item in media),
                {"type": "text", "text": text},
            ],
        }
    return messages


def batch_kind(row: dict[str, Any]) -> str:
    media = json.loads(str(row["media_json"]))
    types = [str(item.get("type", "")).lower() for item in media]
    if not types:
        return "text"
    if len(types) > 1:
        return "multi_image" if set(types) == {"image"} else "other"
    return {"audio": "audio", "image": "image", "video": "video"}.get(types[0], "other")


def generation_batches(
    rows: list[dict[str, Any]], sizes: dict[str, Any]
) -> Iterable[list[dict[str, Any]]]:
    buckets: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        kind = batch_kind(row)
        bucket = buckets[kind]
        bucket.append(row)
        if len(bucket) == int(sizes[kind]):
            yield bucket[:]
            bucket.clear()
    for bucket in buckets.values():
        if bucket:
            yield bucket


def load_thinker(config: dict[str, Any], local_device: int) -> tuple[Any, Any, Any]:
    import torch
    from transformers import (
        Qwen3OmniMoeConfig,
        Qwen3OmniMoeProcessor,
        Qwen3OmniMoeThinkerForConditionalGeneration,
    )

    if not torch.cuda.is_available():
        raise RuntimeError("Thinker data generation requires CUDA")
    torch.cuda.set_device(local_device)
    model_path = str(config["model"]["path"])
    full_config = Qwen3OmniMoeConfig.from_pretrained(model_path)
    processor = Qwen3OmniMoeProcessor.from_pretrained(model_path)
    processor.tokenizer.padding_side = "left"
    # Reuse the target repository's Thinker-only loading strategy. It avoids
    # allocating the unused Talker and Code2Wav weights for text trajectories.
    model = Qwen3OmniMoeThinkerForConditionalGeneration.from_pretrained(
        model_path,
        config=full_config.thinker_config,
        dtype=getattr(torch, str(config["model"]["dtype"])),
        device_map={"": local_device},
        attn_implementation=str(config["model"]["attention"]),
        low_cpu_mem_usage=True,
    ).eval()
    return model, processor, torch


def generated_ids(sequence: list[int], eos_token_id: int) -> tuple[list[int], str]:
    if eos_token_id in sequence:
        end = sequence.index(eos_token_id) + 1
        return sequence[:end], "eos"
    return sequence, "length"


def generate_batch(
    rows: list[dict[str, Any]],
    config: dict[str, Any],
    model: Any,
    processor: Any,
    torch: Any,
) -> list[dict[str, Any]]:
    from qwen_omni_utils import process_mm_info

    generation = config["generation"]
    conversations = [model_conversation(row, generation) for row in rows]
    tools = [json.loads(str(row["tools_json"])) for row in rows]
    rendered = [
        processor.apply_chat_template(
            conversation,
            tools=row_tools or None,
            tokenize=False,
            add_generation_prompt=True,
        )
        for conversation, row_tools in zip(conversations, tools, strict=True)
    ]
    audios, images, videos = process_mm_info(
        conversations, use_audio_in_video=bool(generation["use_audio_in_video"])
    )
    inputs = processor(
        text=rendered,
        audio=audios,
        images=images,
        videos=videos,
        return_tensors="pt",
        padding=True,
        use_audio_in_video=bool(generation["use_audio_in_video"]),
    ).to(model.device).to(model.dtype)
    max_new_tokens = int(generation["max_new_tokens"])
    if inputs["input_ids"].shape[1] + max_new_tokens > int(generation["max_model_tokens"]):
        raise ValueError("processed prompt plus max_new_tokens exceeds Thinker context")

    seed = stable_int(
        generation["sampling_profile"],
        int(generation["master_seed"]),
        [row["condition_id"] for row in rows],
    )
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    output = model.generate(
        **inputs,
        return_dict_in_generate=True,
        max_new_tokens=max_new_tokens,
        eos_token_id=int(generation["eos_token_id"]),
        pad_token_id=processor.tokenizer.pad_token_id,
        do_sample=bool(generation["do_sample"]),
        temperature=float(generation["temperature"]),
        top_p=float(generation["top_p"]),
        top_k=int(generation["top_k"]),
        repetition_penalty=float(generation["repetition_penalty"]),
    )
    sequences = output.sequences
    prompt_width = inputs["input_ids"].shape[1]
    result = []
    for index, row in enumerate(rows):
        prompt_ids = inputs["input_ids"][index][
            inputs["attention_mask"][index].bool()
        ].tolist()
        response_ids, finish_reason = generated_ids(
            sequences[index, prompt_width:].tolist(), int(generation["eos_token_id"])
        )
        response = processor.decode(
            response_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )
        if not response.strip():
            raise ValueError(f"empty Thinker response for {row['condition_id']}")
        # Keep the exact multimodal OpenAI-style request seen by the processor,
        # not just the text-only condition record.
        output_messages = conversations[index]
        output_messages.append({"role": "assistant", "content": response})
        result.append(
            {
                "condition_id": row["condition_id"],
                "source": row["source"],
                "source_subset": row["source_subset"],
                "modality": row["modality"],
                "language": row["language"],
                "task": row["task"],
                "messages_json": canonical_json(output_messages),
                "tools_json": row["tools_json"],
                "media_json": row["media_json"],
                "prompt_token_ids": prompt_ids,
                "response_token_ids": response_ids,
                "response_text": response,
                "prompt_tokens": len(prompt_ids),
                "response_tokens": len(response_ids),
                "finish_reason": finish_reason,
                "sampling_seed": seed,
            }
        )
    return result


def process_shard(
    shard_id: int,
    rows: list[dict[str, Any]],
    config: dict[str, Any],
    output: Path,
    model: Any,
    processor: Any,
    torch: Any,
) -> None:
    shard_path = output / "shards" / f"train-{shard_id:05d}.parquet"
    started = time.perf_counter()
    with ParquetBatchWriter(shard_path, TRAJECTORY_SCHEMA) as writer:
        for batch in generation_batches(rows, config["batch_size"]):
            writer.extend(generate_batch(batch, config, model, processor, torch))
    atomic_write_json(
        output / "shards" / f"train-{shard_id:05d}.success.json",
        {
            "status": "PASS",
            "shard_id": shard_id,
            "conditions": len(rows),
            "generation_fingerprint": generation_fingerprint(config),
            "parquet": shard_path.name,
            "generation_seconds": time.perf_counter() - started,
        },
    )


def completed_conditions(output: Path) -> int:
    """Count rows declared by atomically committed shard markers."""

    if not (output / "shards").is_dir():
        return 0
    return sum(
        int(json.loads(path.read_text(encoding="utf-8"))["conditions"])
        for path in (output / "shards").glob("*.success.json")
    )


def run(config: dict[str, Any], max_shards: int | None) -> None:
    input_path, total_rows = require_verified_input(config)
    _, _, output = paths(config)
    output.mkdir(parents=True, exist_ok=True)
    rank = int(os.environ.get("RANK", os.environ.get("SLURM_PROCID", "0")))
    world_size = int(os.environ.get("WORLD_SIZE", os.environ.get("SLURM_NTASKS", "1")))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    shard_rows = int(config["output"]["conditions_per_shard"])
    expected_shards = math.ceil(total_rows / shard_rows)
    pending = []
    for shard_id in range(expected_shards):
        success = output / "shards" / f"train-{shard_id:05d}.success.json"
        if shard_id % world_size != rank:
            continue
        if success.is_file():
            completed = json.loads(success.read_text(encoding="utf-8"))
            if completed.get("generation_fingerprint") != generation_fingerprint(config):
                raise ValueError(f"generated shard {shard_id} uses a different configuration")
            continue
        pending.append(shard_id)
        if max_shards is not None and len(pending) >= max_shards:
            break
    if not pending:
        print(f"rank={rank}: no pending Thinker shards", flush=True)
        if completed_conditions(output) == total_rows:
            verify(config)
        return
    print(
        f"worker={socket.gethostname()} rank={rank}/{world_size} "
        f"cuda={local_rank} loading Thinker for {len(pending)} shard(s)",
        flush=True,
    )
    model, processor, torch = load_thinker(config, local_rank)
    pending_set = set(pending)
    for shard_id, batch in enumerate(
        pq.ParquetFile(input_path).iter_batches(batch_size=shard_rows)
    ):
        if shard_id not in pending_set:
            continue
        rows = batch.to_pylist()
        process_shard(shard_id, rows, config, output, model, processor, torch)
        print(f"rank={rank}: committed shard {shard_id} ({len(rows)} conditions)", flush=True)
    # The last worker to commit a shard sees the complete marker set and writes
    # the final manifest. The explicit verify command remains only for recovery.
    if completed_conditions(output) == total_rows:
        verify(config)


def verify(config: dict[str, Any]) -> None:
    _, expected = require_verified_input(config)
    _, _, output = paths(config)
    shard_rows = int(config["output"]["conditions_per_shard"])
    expected_shards = math.ceil(expected / shard_rows)
    condition_ids: set[str] = set()
    rows = 0
    finish_reasons: dict[str, int] = defaultdict(int)
    shard_manifest = []
    for shard_id in range(expected_shards):
        parquet = output / "shards" / f"train-{shard_id:05d}.parquet"
        success_path = output / "shards" / f"train-{shard_id:05d}.success.json"
        if not parquet.is_file() or not success_path.is_file():
            raise FileNotFoundError(f"missing generated shard {shard_id}")
        success = json.loads(success_path.read_text(encoding="utf-8"))
        if success.get("generation_fingerprint") != generation_fingerprint(config):
            raise ValueError(f"generated shard {shard_id} uses a different configuration")
        for batch in pq.ParquetFile(parquet).iter_batches(
            columns=["condition_id", "response_token_ids", "finish_reason"]
        ):
            for row in batch.to_pylist():
                condition_id = str(row["condition_id"])
                if condition_id in condition_ids or not row["response_token_ids"]:
                    raise ValueError(f"invalid generated condition {condition_id}")
                condition_ids.add(condition_id)
                finish_reasons[str(row["finish_reason"])] += 1
                rows += 1
        shard_manifest.append(
            {
                "path": str(parquet.relative_to(output)),
                "rows": int(success["conditions"]),
            }
        )
    if rows != expected:
        raise ValueError(f"generated condition count {rows} != {expected}")
    atomic_write_json(
        output / "manifest.json",
        {
            "status": "PASS",
            "dataset_name": config["dataset_name"],
            "conditions": rows,
            "model": config["model"],
            "generation": config["generation"],
            "generation_fingerprint": generation_fingerprint(config),
            "finish_reasons": dict(sorted(finish_reasons.items())),
            "shards": shard_manifest,
        },
    )
    print(f"verification PASS: {rows:,} Thinker trajectories", flush=True)


def main() -> None:
    args = parse_args()
    config = read_config(args.config)
    if args.command == "verify":
        verify(config)
    else:
        run(config, args.max_shards)


if __name__ == "__main__":
    main()
