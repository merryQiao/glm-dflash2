#!/usr/bin/env python3
"""Qwen3-Omni inference with per-stage CUDA timing.

Usage
-----
Activate the project environment first::

source /inspire/ssd/project/sais-bio/public/chenbaoyou/miniconda3/bin/activate
conda activate specforge

Run Thinker-only inference and generate text::

    python inference_qwen3-omni.py \
        --text "Please introduce yourself." \
        --text-only \
        --output-jsonl outputs/qwen3_omni_text.jsonl

Run full inference and generate both text and speech::

    python inference_qwen3-omni.py \
        --text "Please introduce yourself." \
        --output-jsonl outputs/qwen3_omni_text_and_speech.jsonl \
        --audio-output-dir outputs/qwen3_omni_audio

Run one local audio or image sample::

    python inference_qwen3-omni.py \
        --text "Describe the input." \
        --audio asserts/cough.wav \
        --image asserts/cars.jpg

Run a real JSONL dataset::

    python inference_qwen3-omni.py \
        --input-jsonl asserts/input.jsonl \
        --output-jsonl outputs/qwen3_omni_results.jsonl \
        --audio-output-dir outputs/qwen3_omni_audio

Run a downloaded benchmark and report its deterministic task metric::

    python inference_qwen3-omni.py \
        --benchmark mmstar \
        --text-only \
        --output-jsonl outputs/mmstar.jsonl

Run a speech-generation benchmark through the full pipeline::

    python inference_qwen3-omni.py \
        --benchmark seed-tts-en \
        --output-jsonl outputs/seed_tts_en.jsonl \
        --audio-output-dir outputs/seed_tts_en_audio

Each JSONL record can use convenient fields::

    {"id":"001","text":"Describe this audio.","audio":"audio/001.wav"}

or the native Qwen multimodal message format::

    {"id":"002","messages":[{"role":"user","content":[
      {"type":"image","image":"images/002.jpg"},
      {"type":"text","text":"What is in this image?"}]}]}

Relative media paths are resolved against the input JSONL directory. The
profile contains Audio Encoder, Vision Encoder, Thinker, Talker, MTP (the
Talker Code Predictor), and Code2wav. Use ``--text-only`` to skip speech
generation; Talker, MTP, and Code2wav will then report zero calls.
"""

from __future__ import annotations

import argparse
import copy
import functools
import json
import os
import sys
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Sequence

import numpy as np
import torch
from torch import Tensor, nn

from benchmark_helper import (
    BENCHMARKS,
    evaluate_benchmark,
    iter_benchmark_records,
)


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
DEFAULT_MODEL = PROJECT_ROOT / "pretrained_models/Qwen/Qwen3-Omni-30B-A3B-Instruct"

STAGE_MODULE_PATHS = {
    "Audio Encoder": "thinker.audio_tower",
    "Vision Encoder": "thinker.visual",
    "Thinker": "thinker.model",
    "Talker": "talker.model",
    "MTP": "talker.code_predictor",
}
STAGES = (*STAGE_MODULE_PATHS, "Code2wav")


@dataclass(frozen=True)
class InputSample:
    sample_id: str
    messages: list[dict[str, Any]]
    benchmark: str | None = None
    metadata: dict[str, Any] | None = None
    use_audio_in_video: bool = False


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run Qwen3-Omni inference and profile its six stages."
    )
    parser.add_argument("--model", type=Path, default=DEFAULT_MODEL)

    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--input-jsonl", type=Path)
    source.add_argument("--text")
    source.add_argument("--benchmark", choices=BENCHMARKS)
    parser.add_argument(
        "--benchmark-root",
        type=Path,
        default=SCRIPT_DIR / "benchmarks/qwen3_omni",
    )
    parser.add_argument("--audio", type=Path, action="append", default=[])
    parser.add_argument("--image", type=Path, action="append", default=[])
    parser.add_argument("--limit", type=int)

    parser.add_argument(
        "--output-jsonl",
        type=Path,
        default=Path("outputs/qwen3_omni_inference.jsonl"),
    )
    parser.add_argument("--profile-json", type=Path)
    parser.add_argument(
        "--audio-output-dir",
        type=Path,
        default=Path("outputs/qwen3_omni_audio"),
    )
    parser.add_argument("--overwrite", action="store_true")

    parser.add_argument("--device", default="cuda:0")
    parser.add_argument(
        "--dtype",
        choices=("bfloat16", "float16", "float32"),
        default="bfloat16",
    )
    parser.add_argument(
        "--attn-implementation",
        choices=("sdpa", "flash_attention_2", "eager"),
        default="sdpa",
    )
    parser.add_argument("--speaker", default="Ethan")
    parser.add_argument("--thinker-max-new-tokens", type=int, default=128)
    parser.add_argument("--talker-max-new-tokens", type=int, default=2048)
    parser.add_argument("--text-only", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> None:
    if not torch.cuda.is_available():
        raise RuntimeError("Qwen3-Omni inference and timing require CUDA")
    if not args.device.startswith("cuda:"):
        raise ValueError("--device must have the form cuda:<index>")
    if not (args.model / "config.json").is_file():
        raise FileNotFoundError(f"model checkpoint not found: {args.model}")
    if args.input_jsonl is not None and not args.input_jsonl.is_file():
        raise FileNotFoundError(args.input_jsonl)
    if args.limit is not None and args.limit <= 0:
        raise ValueError("--limit must be positive")
    if args.thinker_max_new_tokens <= 0 or args.talker_max_new_tokens <= 0:
        raise ValueError("generation token limits must be positive")


def list_value(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def resolve_media_path(value: Any, base_dir: Path) -> Any:
    if not isinstance(value, str):
        return value
    if value.startswith(("http://", "https://", "file://", "data:")):
        return value
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = base_dir / path
    return str(path.resolve())


def resolve_message_paths(
    messages: Sequence[dict[str, Any]], base_dir: Path
) -> list[dict[str, Any]]:
    messages = copy.deepcopy(list(messages))
    for message in messages:
        content = message.get("content")
        if not isinstance(content, list):
            continue
        for item in content:
            if not isinstance(item, dict):
                continue
            media_type = item.get("type")
            if media_type in {"audio", "image", "video"}:
                item[media_type] = resolve_media_path(item[media_type], base_dir)
    return messages


def build_sample(record: dict[str, Any], index: int, base_dir: Path) -> InputSample:
    sample_id = str(record.get("id", record.get("prompt_id", index)))

    if "messages" in record:
        messages = record["messages"]
        if not isinstance(messages, list) or not messages:
            raise ValueError(f"record {sample_id} has invalid messages")
        return InputSample(
            sample_id,
            resolve_message_paths(messages, base_dir),
            record.get("benchmark"),
            record.get("metadata"),
            bool(record.get("use_audio_in_video", False)),
        )

    text = record.get("text")
    if not isinstance(text, str) or not text.strip():
        raise ValueError(f"record {sample_id} has no text")

    content: list[dict[str, Any]] = []
    for audio in list_value(record.get("audio")):
        content.append({"type": "audio", "audio": resolve_media_path(audio, base_dir)})
    for image in list_value(record.get("image")):
        content.append({"type": "image", "image": resolve_media_path(image, base_dir)})
    for video in list_value(record.get("video")):
        content.append({"type": "video", "video": resolve_media_path(video, base_dir)})
    content.append({"type": "text", "text": text})
    return InputSample(
        sample_id,
        [{"role": "user", "content": content}],
        record.get("benchmark"),
        record.get("metadata"),
        bool(record.get("use_audio_in_video", False)),
    )


def iter_samples(args: argparse.Namespace) -> Iterator[InputSample]:
    if args.benchmark is not None:
        for index, record in enumerate(
            iter_benchmark_records(args.benchmark, args.benchmark_root.resolve())
        ):
            yield build_sample(record, index, args.benchmark_root.resolve())
            if args.limit is not None and index + 1 >= args.limit:
                return
        return

    if args.text is not None:
        record = {
            "id": "command-line",
            "text": args.text,
            "audio": [str(path.resolve()) for path in args.audio],
            "image": [str(path.resolve()) for path in args.image],
        }
        yield build_sample(record, 0, Path.cwd())
        return

    assert args.input_jsonl is not None
    base_dir = args.input_jsonl.resolve().parent
    emitted = 0
    with args.input_jsonl.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            record = json.loads(line)
            if not isinstance(record, dict):
                raise ValueError(
                    f"{args.input_jsonl}:{line_number} is not a JSON object"
                )
            yield build_sample(record, line_number - 1, base_dir)
            emitted += 1
            if args.limit is not None and emitted >= args.limit:
                return


def load_model(args: argparse.Namespace) -> tuple[Any, Any, float]:
    # Import the local Qwen3-Omni implementation without installing the project.
    source_root = PROJECT_ROOT / "src"
    if str(source_root) not in sys.path:
        sys.path.insert(0, str(source_root))
    from diffusion_omni.models.qwen3_omni_moe import (
        Qwen3OmniMoeConfig,
        Qwen3OmniMoeForConditionalGeneration,
        Qwen3OmniMoeProcessor,
    )

    dtype = {
        "bfloat16": torch.bfloat16,
        "float16": torch.float16,
        "float32": torch.float32,
    }[args.dtype]
    device_index = int(args.device.split(":", 1)[1])
    torch.cuda.set_device(device_index)

    started = time.perf_counter()
    config = Qwen3OmniMoeConfig.from_pretrained(args.model)
    if not hasattr(config, "initializer_range"):
        config.initializer_range = config.thinker_config.text_config.initializer_range
    processor = Qwen3OmniMoeProcessor.from_pretrained(args.model)
    model = Qwen3OmniMoeForConditionalGeneration.from_pretrained(
        args.model,
        config=config,
        dtype=dtype,
        device_map={"": device_index},
        attn_implementation=args.attn_implementation,
        low_cpu_mem_usage=True,
    ).eval()
    torch.cuda.synchronize(device_index)
    return model, processor, time.perf_counter() - started


class StageProfiler:
    """Measure CUDA time for the six logical inference stages."""

    def __init__(self, model: nn.Module) -> None:
        self.active = False
        self.events: dict[str, list[tuple[torch.cuda.Event, torch.cuda.Event]]] = {
            stage: [] for stage in STAGES
        }
        self.starts: dict[str, list[torch.cuda.Event]] = {stage: [] for stage in STAGES}
        self.warmup_complete = {stage: False for stage in STAGES}
        self.warmup_calls = {stage: 0 for stage in STAGES}
        self.module_paths = dict(STAGE_MODULE_PATHS)
        self.module_paths["Code2wav"] = "code2wav.chunked_decode"

        # Profile decoder backbones separately from encoders and MTP.
        for stage, path in STAGE_MODULE_PATHS.items():
            module = model.get_submodule(path)
            module.register_forward_pre_hook(self._pre_hook(stage))
            module.register_forward_hook(self._post_hook(stage))

        # Code2wav is entered through chunked_decode instead of nn.Module.forward.
        original_decode = model.code2wav.chunked_decode

        @functools.wraps(original_decode)
        def timed_decode(*args: Any, **kwargs: Any) -> Any:
            self._start("Code2wav")
            output = original_decode(*args, **kwargs)
            self._stop("Code2wav")
            return output

        model.code2wav.chunked_decode = timed_decode

    def _pre_hook(self, stage: str):
        def hook(_module: nn.Module, _inputs: tuple[Any, ...]) -> None:
            self._start(stage)

        return hook

    def _post_hook(self, stage: str):
        def hook(_module: nn.Module, _inputs: tuple[Any, ...], _output: Any) -> None:
            self._stop(stage)

        return hook

    def _start(self, stage: str) -> None:
        if not self.active:
            return
        event = torch.cuda.Event(enable_timing=True)
        event.record()
        self.starts[stage].append(event)

    def _stop(self, stage: str) -> None:
        if not self.active:
            return
        end = torch.cuda.Event(enable_timing=True)
        end.record()
        start = self.starts[stage].pop()
        self.events[stage].append((start, end))
        if not self.warmup_complete[stage]:
            self.warmup_complete[stage] = True
            self.warmup_calls[stage] += 1

    def begin(self) -> None:
        for stage in STAGES:
            self.events[stage].clear()
            self.starts[stage].clear()
            self.warmup_calls[stage] = 0
        self.active = True

    def end(self) -> None:
        self.active = False
        torch.cuda.synchronize()

    def summary(self) -> dict[str, dict[str, Any]]:
        profile = {}
        for stage in STAGES:
            durations = [start.elapsed_time(end) for start, end in self.events[stage]]
            total_ms = float(sum(durations))
            warmup_calls = self.warmup_calls[stage]
            warmup_ms = float(sum(durations[:warmup_calls]))
            measured_durations = durations[warmup_calls:]
            profile[stage] = {
                "module": self.module_paths[stage],
                "calls": len(durations),
                "warmup_calls": warmup_calls,
                "warmup_cuda_ms": round(warmup_ms, 3),
                "total_cuda_ms": round(total_ms, 3),
                "mean_call_cuda_ms": (
                    round(sum(measured_durations) / len(measured_durations), 3)
                    if measured_durations
                    else 0.0
                ),
            }
        return profile


def prepare_inputs(
    processor: Any,
    messages: Sequence[dict[str, Any]],
    use_audio_in_video: bool,
) -> Any:
    from qwen_omni_utils import process_mm_info

    # Build the official multimodal chat representation and load real media.
    prompt = processor.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=False,
    )
    audios, images, videos = process_mm_info(
        messages,
        use_audio_in_video=use_audio_in_video,
    )
    return processor(
        text=prompt,
        audio=audios,
        images=images,
        videos=videos,
        return_tensors="pt",
        padding=False,
        use_audio_in_video=use_audio_in_video,
    )


def move_inputs(inputs: Any, model: nn.Module) -> Any:
    # BatchFeature keeps integer token IDs unchanged while casting media tensors.
    return inputs.to(model.device).to(model.dtype)


def generation_kwargs(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "speaker": args.speaker,
        "return_audio": not args.text_only,
        "thinker_max_new_tokens": args.thinker_max_new_tokens,
        "thinker_eos_token_id": 151645,
        "thinker_do_sample": False,
        "talker_max_new_tokens": args.talker_max_new_tokens,
        "talker_do_sample": True,
        "talker_top_k": 50,
        "talker_top_p": 1.0,
        "talker_temperature": 0.9,
        "talker_repetition_penalty": 1.05,
    }


def unpack_generation(result: Any) -> tuple[Tensor, Any | None]:
    if isinstance(result, tuple):
        return result[0], result[1] if len(result) > 1 else None
    return getattr(result, "sequences", result), getattr(result, "audio", None)


def generated_token_ids(sequences: Tensor, input_ids: Tensor) -> Tensor:
    # Some generation implementations return prompt + response; others return response only.
    prompt_length = input_ids.shape[1]
    if sequences.shape[1] >= prompt_length and torch.equal(
        sequences[:, :prompt_length], input_ids
    ):
        return sequences[:, prompt_length:]
    return sequences


def audio_array(audio: Any) -> np.ndarray | None:
    if audio is None:
        return None
    if isinstance(audio, (list, tuple)):
        audio = audio[0]
    if isinstance(audio, Tensor):
        audio = audio.detach().float().cpu().numpy()
    samples = np.asarray(audio, dtype=np.float32).squeeze()
    if samples.ndim != 1:
        raise ValueError(f"unexpected generated audio shape: {samples.shape}")
    return samples


def safe_filename(sample_id: str) -> str:
    name = "".join(
        char if char.isalnum() or char in "-_" else "_" for char in sample_id
    )
    return name[:120] or "sample"


def save_audio(path: Path, samples: np.ndarray, sampling_rate: int = 24_000) -> None:
    import soundfile as sf

    path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(path, samples, sampling_rate)


def run_sample(
    args: argparse.Namespace,
    sample: InputSample,
    sample_index: int,
    model: Any,
    processor: Any,
    profiler: StageProfiler,
) -> dict[str, Any]:
    preprocess_started = time.perf_counter()
    inputs = move_inputs(
        prepare_inputs(processor, sample.messages, sample.use_audio_in_video),
        model,
    )
    preprocess_ms = (time.perf_counter() - preprocess_started) * 1_000

    seed = args.seed + sample_index
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.reset_peak_memory_stats(model.device)
    torch.cuda.synchronize(model.device)

    # CUDA events profile module work; wall time measures complete generation.
    profiler.begin()
    generate_started = time.perf_counter()
    with torch.inference_mode():
        result = model.generate(**inputs, **generation_kwargs(args))
    profiler.end()
    generate_wall_ms = (time.perf_counter() - generate_started) * 1_000

    sequences, waveform = unpack_generation(result)
    output_ids = generated_token_ids(sequences, inputs["input_ids"])
    generated_text = processor.batch_decode(
        output_ids,
        skip_special_tokens=True,
        clean_up_tokenization_spaces=False,
    )[0]

    generated_audio = audio_array(waveform)
    audio_path = None
    if generated_audio is not None:
        audio_path = args.audio_output_dir / f"{safe_filename(sample.sample_id)}.wav"
        save_audio(audio_path, generated_audio)

    record = {
        "id": sample.sample_id,
        "generated_text": generated_text,
        "generated_audio": str(audio_path.resolve()) if audio_path else None,
        "prompt_tokens": int(inputs["input_ids"].shape[-1]),
        "generated_text_tokens": int(output_ids.shape[-1]),
        "seed": seed,
        "preprocess_ms": round(preprocess_ms, 3),
        "generate_wall_ms": round(generate_wall_ms, 3),
        "peak_cuda_memory_mib": round(
            torch.cuda.max_memory_allocated(model.device) / 1024**2,
            2,
        ),
        "stage_profile": profiler.summary(),
    }
    if sample.benchmark is not None:
        record.update(
            {"benchmark": sample.benchmark, "benchmark_metadata": sample.metadata}
        )
    return record


def aggregate_profiles(records: Sequence[dict[str, Any]]) -> dict[str, Any]:
    total_ms = defaultdict(float)
    total_calls = defaultdict(int)
    warmup_ms = defaultdict(float)
    warmup_calls = defaultdict(int)
    for record in records:
        for stage, metrics in record["stage_profile"].items():
            total_ms[stage] += float(metrics["total_cuda_ms"])
            total_calls[stage] += int(metrics["calls"])
            warmup_ms[stage] += float(metrics["warmup_cuda_ms"])
            warmup_calls[stage] += int(metrics["warmup_calls"])

    stages = {}
    for stage in STAGES:
        calls = total_calls[stage]
        measured_calls = calls - warmup_calls[stage]
        measured_ms = total_ms[stage] - warmup_ms[stage]
        stages[stage] = {
            "module": records[0]["stage_profile"][stage]["module"],
            "calls": calls,
            "total_cuda_ms": round(total_ms[stage], 3),
            "mean_record_cuda_ms": round(total_ms[stage] / len(records), 3),
            "mean_call_cuda_ms": (
                round(measured_ms / measured_calls, 3) if measured_calls else 0.0
            ),
        }
    summary = {
        "records": len(records),
        "mean_generate_wall_ms": round(
            sum(record["generate_wall_ms"] for record in records) / len(records),
            3,
        ),
        "stages": stages,
    }
    evaluation = evaluate_benchmark(records) if records[0].get("benchmark") else None
    if evaluation is not None:
        summary["evaluation"] = evaluation
    return summary


def print_profile(summary: dict[str, Any]) -> None:
    print("\nStage profile (CUDA time)")
    print(
        f"{'Stage':<16} {'Calls':>8} {'Total ms':>14} "
        f"{'ms / record':>14} {'ms / call':>14}"
    )
    for stage in STAGES:
        metrics = summary["stages"][stage]
        print(
            f"{stage:<16} {metrics['calls']:>8d} "
            f"{metrics['total_cuda_ms']:>14.3f} "
            f"{metrics['mean_record_cuda_ms']:>14.3f} "
            f"{metrics['mean_call_cuda_ms']:>14.3f}"
        )
    print(f"Mean generation wall time: {summary['mean_generate_wall_ms']:.3f} ms")
    if "evaluation" in summary:
        evaluation = summary["evaluation"]
        comparison = f"paper: {evaluation['paper_claimed_value']:.3f}"
        if evaluation["full_benchmark"]:
            comparison += f", difference: {evaluation['difference_from_paper']:+.3f}"
        else:
            comparison += ", partial run"
        print(f"{evaluation['metric']}: {evaluation['value']:.3f} ({comparison})")


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def main() -> None:
    args = parse_args()
    validate_args(args)
    profile_json = args.profile_json or args.output_jsonl.with_suffix(".profile.json")
    if not args.overwrite:
        for path in (args.output_jsonl, profile_json):
            if path.exists():
                raise FileExistsError(f"output already exists: {path}")

    args.output_jsonl.parent.mkdir(parents=True, exist_ok=True)
    args.audio_output_dir.mkdir(parents=True, exist_ok=True)
    model, processor, load_seconds = load_model(args)
    profiler = StageProfiler(model)

    print("Profile modules:")
    for stage in STAGES:
        print(f"  {stage}: {profiler.module_paths[stage]}")

    records = []
    with args.output_jsonl.open("w", encoding="utf-8") as output_handle:
        for sample_index, sample in enumerate(iter_samples(args)):
            record = run_sample(args, sample, sample_index, model, processor, profiler)

            # Write every completed sample immediately for long dataset runs.
            output_handle.write(json.dumps(record, ensure_ascii=False) + "\n")
            output_handle.flush()
            records.append(record)
            print(
                json.dumps(
                    {
                        "id": record["id"],
                        "generated_text": record["generated_text"],
                        "generated_audio": record["generated_audio"],
                        "generate_wall_ms": record["generate_wall_ms"],
                    },
                    ensure_ascii=False,
                )
            )

    if not records:
        raise RuntimeError("no input records were found")
    summary = aggregate_profiles(records)
    summary.update(
        {
            "model": str(args.model.resolve()),
            "device": args.device,
            "dtype": args.dtype,
            "attn_implementation": args.attn_implementation,
            "model_load_seconds": round(load_seconds, 3),
            "output_jsonl": str(args.output_jsonl.resolve()),
            "benchmark": args.benchmark,
        }
    )
    write_json(profile_json, summary)
    print_profile(summary)
    print(f"Results: {args.output_jsonl.resolve()}")
    print(f"Profile: {profile_json.resolve()}")


if __name__ == "__main__":
    main()
